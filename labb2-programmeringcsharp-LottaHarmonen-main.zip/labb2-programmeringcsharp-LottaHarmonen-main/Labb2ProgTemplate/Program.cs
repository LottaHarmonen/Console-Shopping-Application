﻿using Labb2ProgTemplate.Services;
Console.OutputEncoding = System.Text.Encoding.UTF8;

Shop ButterflyBeautyShop = new Shop();

ButterflyBeautyShop.MainMenu();

